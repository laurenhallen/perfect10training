import React from 'react';

function Trainers() {
    return (
        <h1>I am the trainers page</h1>
    )
}

export default Trainers