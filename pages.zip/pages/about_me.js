import React from 'react'

export default function AboutMe() {
    return (
        <div>
            <a href="/">back to home</a>
        </div>
    );
}